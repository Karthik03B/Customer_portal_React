export interface Customer {
    id: number;
    name: string;
    title: string;
    address: string;
    email: string;
    phone: string;
    photos: string[];
  }
  